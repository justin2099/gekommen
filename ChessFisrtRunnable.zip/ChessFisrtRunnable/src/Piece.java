public enum Piece {
    BLANK, WHITE, BLACK;
}
