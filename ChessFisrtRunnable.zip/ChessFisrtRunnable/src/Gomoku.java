public class Gomoku {
    public static void main(String[] args) {
        new aGame(15).play();
    }
}
